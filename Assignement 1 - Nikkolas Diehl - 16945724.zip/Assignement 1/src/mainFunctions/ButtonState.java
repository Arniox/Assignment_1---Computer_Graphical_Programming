package mainFunctions;

/**
 * 
 * @author Nikkolas Diehl - 16945724
 *
 */
public enum ButtonState {
	
	//Set up ButtonState states
	CLICKED, NOT_CLICKED, HOVER;
}
